/*
 * Name: Karin Galicia
 * course: CSC 135-1
 * Project: Problem 1.1
 * File name: FavoriteCity.java
 */

public class FavoriteCity {

    public static void main(String[] args) {
        System.out.println("My favorite city is Mexico City.\nSome of it's landmarks are museum of Bellas Artes and the Latino American Tower.");
    }
    
}
