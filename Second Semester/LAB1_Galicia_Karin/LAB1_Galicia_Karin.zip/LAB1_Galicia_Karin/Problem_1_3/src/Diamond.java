/*
 * Name: Karin Galicia
 * course: CSC 135-1
 * Project: Problem 1.3
 * File name: Diamond.java
 */

public class Diamond {

    public static void main(String[] args) {
        System.out.println("    *");
        System.out.println("   ***");
        System.out.println("  *****");
        System.out.println(" *******");
        System.out.println("*********");
        System.out.println(" *******");
        System.out.println("  *****");
        System.out.println("   ***");
        System.out.println("    *");
    }
    
}
