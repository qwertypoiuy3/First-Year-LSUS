/*
 * Name: Karin Galicia
 * course: CSC 135-1
 * Project: Problem 1.2
 * File name: Diamond.java
 */

public class Simple {

    public static void main(String[] args) {
        System.out.println("simple" + "     \tsimple would be an acceptable identifier, but it's not correct.");
        System.out.println("SimpleProgram" + "  \tSimple program would be a good identfier.");
        System.out.println("1 Simple" + "\t1 Simple would'nt be a good identifier because it starts with a number.");
        System.out.println("_Simple_" + "\t_Simple_ would be an acceptable identifier.");
        System.out.println("*Simple*" + "\t*Simple* would'nt be a good identifier because it starts with a different kind of character.");
        System.out.println("$123_45" + "    \t$123_45 would be an acceptable identifier.");
        System.out.println("Simple!" + "    \tSimple! wouldn't be an acceptable identifier because it has !");
    }
    
}
